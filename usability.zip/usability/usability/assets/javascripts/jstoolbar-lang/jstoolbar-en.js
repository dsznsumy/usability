jsToolBar.strings['Cut'] = 'Hide the content';
jsToolBar.strings['us_text_color'] = 'Text color';